#include <iostream>
#include "bfs.h"
#include <queue>
#include <algorithm>

// Naimplementujte efektivni algoritmus pro nalezeni nejkratsi cesty v grafu.
// V teto metode nemusite prilis optimalizovat pametove naroky, a vhodnym algo-
// ritmem tak muze byt napriklad pouziti prohledavani do sirky (breadth-first
// search.
//
// Metoda ma za ukol vratit ukazatel na cilovy stav, ktery je dosazitelny pomoci
// nejkratsi cesty.
std::shared_ptr<const state> bfs(std::shared_ptr<const state> root) {

    std::queue<std::shared_ptr<const state>> fronta;
    fronta.push(root);
    std::shared_ptr<const state> curr;
    std::shared_ptr<const state> ret;
    std::vector<unsigned long long int > beenIn;
    while(!fronta.empty()){

        curr = fronta.front();
        fronta.pop();
        if(curr->is_goal()){
            ret = curr;
            break;
        }
        std::vector<std::shared_ptr<const state>> nxt = curr->next_states();
        for(auto state : nxt){
            //std::cout << state->get_identifier() << std::endl;
            unsigned long long int id = state->get_identifier();
            if(std::find(beenIn.begin(),beenIn.end(),id)==beenIn.end()){
                fronta.push(state);
                beenIn.push_back(id);
                //std::cout << id << std::endl;
            }
        }
        //std::cout << "Still here" << std::endl;
    }
    //std::cout << "KONEC" << std::endl;
    //std::cout << ret->get_identifier() << std::endl;
    return ret;
}